package com.aufarijaal.aufa_19040079;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class BookingAdapter extends RecyclerView.Adapter<BookingAdapter.MyViewHolder> {

    private Context context;
    private ArrayList nama, tanggal_booking, lapangan, mulai_main, lama_main, harga;

    public BookingAdapter(Context context, ArrayList nama, ArrayList tanggal_booking, ArrayList lapangan, ArrayList mulai_main, ArrayList lama_main, ArrayList harga) {
        this.context = context;
        this.nama = nama;
        this.tanggal_booking = tanggal_booking;
        this.lapangan = lapangan;
        this.mulai_main = mulai_main;
        this.lama_main = lama_main;
        this.harga = harga;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.single_rv_item, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BookingAdapter.MyViewHolder holder, int position) {
        holder.tvTanggalBooking.setText(String.valueOf(tanggal_booking.get(position)));
        holder.tvNama.setText(String.valueOf(nama.get(position)));
        holder.tvLapangan.setText(String.valueOf(lapangan.get(position)));
        holder.tvMulaiMain.setText(String.valueOf(mulai_main.get(position)));
        holder.tvLamaMain.setText(String.valueOf(lama_main.get(position)));
        holder.tvHarga.setText(String.valueOf(harga.get(position)));
        holder.each.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), DetailActivity.class);
                intent.putExtra("nama", holder.tvNama.getText().toString());
                intent.putExtra("tanggal_booking", holder.tvTanggalBooking.getText().toString());
                intent.putExtra("lapangan", holder.tvLapangan.getText().toString());
                intent.putExtra("mulai_main", holder.tvMulaiMain.getText().toString());
                intent.putExtra("lama_main", holder.tvLamaMain.getText().toString());
                intent.putExtra("harga", holder.tvHarga.getText().toString());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return nama.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView tvNama, tvTanggalBooking, tvLapangan, tvMulaiMain, tvLamaMain, tvHarga;
        ConstraintLayout each;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNama = itemView.findViewById(R.id.single_nama);
            tvTanggalBooking = itemView.findViewById(R.id.single_tanggal_booking);
            tvLapangan = itemView.findViewById(R.id.single_lapangan);
            tvMulaiMain = itemView.findViewById(R.id.single_mulai_main);
            tvLamaMain = itemView.findViewById(R.id.single_lama_main);
            tvHarga = itemView.findViewById(R.id.single_harga);
            each = itemView.findViewById(R.id.each);
        }
    }
}
