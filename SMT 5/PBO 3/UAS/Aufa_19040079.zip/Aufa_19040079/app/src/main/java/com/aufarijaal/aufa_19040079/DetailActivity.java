package com.aufarijaal.aufa_19040079;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        final TextView label_nama = findViewById(R.id.t_nama);
        final TextView label_tanggal_booking = findViewById(R.id.t_tanggal_booking);
        final TextView label_mulai_main = findViewById(R.id.t_mulai_main);
        final TextView label_lama_main = findViewById(R.id.t_lama_main);
        final TextView label_lapangan = findViewById(R.id.t_lapangan);
        final TextView label_harga = findViewById(R.id.t_harga);
        final Button btn_kembali = findViewById(R.id.btn_back_to_main);

        Bundle extras = getIntent().getExtras();
        String nama = null;
        String tanggal_booking = null;
        String mulai_main = null;
        String lama_main = null;
        String lapangan = null;
        String harga = null;

        if(extras != null) {
            nama = extras.getString("nama");
            mulai_main = extras.getString("mulai_main");
            lama_main = extras.getString("lama_main");
            lapangan = extras.getString("lapangan");
            tanggal_booking = extras.getString("tanggal_booking");
            harga = extras.getString("harga");


            label_nama.setText(nama);
            label_tanggal_booking.setText(tanggal_booking);
            label_mulai_main.setText(mulai_main);
            label_lama_main.setText(lama_main);
            label_lapangan.setText(lapangan);
            label_harga.setText(harga);
        }

        btn_kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DetailActivity.this, MainActivity.class));
            }
        });
    }
}