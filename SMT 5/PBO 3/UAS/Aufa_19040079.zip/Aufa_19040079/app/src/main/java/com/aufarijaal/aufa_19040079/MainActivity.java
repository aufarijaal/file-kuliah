package com.aufarijaal.aufa_19040079;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    DatabaseHandler myDB;
    ArrayList<String> nama, tanggal_booking, lapangan, mulai_main, lama_main, harga;
    BookingAdapter bookingAdapter;
    RecyclerView rv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rv = findViewById(R.id.list_booking);
        ActionBar bar = getSupportActionBar();
        assert bar != null;
        bar.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.purple_700)));

        myDB = new DatabaseHandler(MainActivity.this);
        nama = new ArrayList<>();
        tanggal_booking = new ArrayList<>();
        lapangan = new ArrayList<>();
        mulai_main = new ArrayList<>();
        lama_main = new ArrayList<>();
        harga = new ArrayList<>();

        storeDataInArrays();

        bookingAdapter = new BookingAdapter(MainActivity.this, nama, tanggal_booking, lapangan, mulai_main, lama_main, harga);
        rv.setAdapter(bookingAdapter);
        rv.setLayoutManager(new LinearLayoutManager(MainActivity.this));
    }
    void storeDataInArrays() {
        Cursor cursor = myDB.readAllData();
        if(cursor.getColumnCount() == 0) {
            Toast.makeText(this, "No data", Toast.LENGTH_SHORT).show();
        }else {
            while(cursor.moveToNext()) {
                tanggal_booking.add(cursor.getString(1));
                nama.add(cursor.getString(2));
                lapangan.add(cursor.getString(3));
                harga.add(Integer.toString(cursor.getInt(4)));
                lama_main.add(cursor.getString(5));
                mulai_main.add(cursor.getString(6));
            }
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.home_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.btn_tambah) {
            Intent intent = new Intent(MainActivity.this, FormActivity.class);
            startActivity(intent);
        }
        else if(item.getItemId() == R.id.btn_lapangan) {
            Intent intent = new Intent(MainActivity.this, LapanganActivity1.class);
            startActivity(intent);
        }
        else if(item.getItemId() == R.id.btn_refresh) {
            myDB = new DatabaseHandler(MainActivity.this);
            nama = new ArrayList<>();
            tanggal_booking = new ArrayList<>();
            lapangan = new ArrayList<>();
            mulai_main = new ArrayList<>();
            lama_main = new ArrayList<>();
            harga = new ArrayList<>();

            storeDataInArrays();

            bookingAdapter = new BookingAdapter(MainActivity.this, nama, tanggal_booking, lapangan, mulai_main, lama_main, harga);
            rv.setAdapter(bookingAdapter);
            rv.setLayoutManager(new LinearLayoutManager(MainActivity.this));
            Toast.makeText(this, "refreshed", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
}