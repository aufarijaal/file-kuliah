# ARDUINO RELAY
Relay library for Arduino.

# SCHEMATICS
designed using <a href="http://fritzing.org/home/">Fritzing</a>

Fritzing part from <a href="https://github.com/rwaldron/fritzing-components/">rwaldron/fritzing-components/</a>

# normally closed
![alt tag](http://i.imgur.com/94be68T.png)

# normally open
![alt tag](http://i.imgur.com/5AWMhpd.png)
