package com.aufarijaal.aufa_19040079;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class FormProsesActivity extends AppCompatActivity {

    DatabaseHandler handler;
    protected Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_proses);

        handler = new DatabaseHandler(this);
        final TextView label_nama = findViewById(R.id.kon_nama);
        final TextView label_tanggal_booking = findViewById(R.id.kon_tanggal_booking);
        final TextView label_mulai_main = findViewById(R.id.kon_mulai_main);
        final TextView label_lama_main = findViewById(R.id.kon_lama_main);
        final TextView label_lapangan = findViewById(R.id.kon_lapangan);
        final TextView label_harga = findViewById(R.id.kon_harga);
        final Button btn_proses = findViewById(R.id.btn_proses);

        Bundle extras = getIntent().getExtras();
        String nama = null;
        String mulai_main = null;
        String lama_main = null;
        String lapangan = null;
        String[] harga_harga = {"60000", "120000", "180000", "240000", "300000"};

        if(extras != null) {
            nama = extras.getString("nama");
            mulai_main = extras.getString("mulai_main");
            lama_main = extras.getString("lama_main");
            lapangan = extras.getString("lapangan");

            label_nama.setText(nama);
            label_tanggal_booking.setText(new SimpleDateFormat("EEEE d MMMM yyyy HH.mm").format(Calendar.getInstance().getTime()));
            label_mulai_main.setText(mulai_main);
            label_lama_main.setText(lama_main);
            label_lapangan.setText(lapangan);
            switch (lama_main) {
                case "1 Jam":
                    label_harga.setText(harga_harga[0]);
                    break;
                case "2 Jam":
                    label_harga.setText(harga_harga[1]);
                    break;
                case "3 Jam":
                    label_harga.setText(harga_harga[2]);
                    break;
                case "4 Jam":
                    label_harga.setText(harga_harga[3]);
                    break;
                case "5 Jam":
                    label_harga.setText(harga_harga[4]);
                    break;
            }
        }else {
            Toast.makeText(this, "extras is null", Toast.LENGTH_SHORT).show();
        }
        btn_proses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    handler.tambahBooking(label_tanggal_booking.getText().toString(),label_nama.getText().toString(), label_lapangan.getText().toString(), Integer.parseInt(label_harga.getText().toString()), label_lama_main.getText().toString(), label_mulai_main.getText().toString());
                Toast.makeText(FormProsesActivity.this, "Data berhasil ditambahkan", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(FormProsesActivity.this, MainActivity.class));
            }
        });
    }
}