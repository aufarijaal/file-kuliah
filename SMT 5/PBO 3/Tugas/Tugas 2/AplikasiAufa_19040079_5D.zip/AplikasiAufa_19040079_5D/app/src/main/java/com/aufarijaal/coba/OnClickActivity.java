package com.aufarijaal.coba;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class OnClickActivity extends AppCompatActivity {
    TextView displayNamaKucing;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onclick);

        displayNamaKucing = findViewById(R.id.catName);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String value = extras.getString("namaKucing");
            //The key argument here must match that used in the other activity
            displayNamaKucing.setText("Anda checkout kucing jenis " + value);
        }
    }
}