package com.aufarijaal.aufa_19040079;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class FormActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);

        final Button btnKeFormProses = findViewById(R.id.btn_ke_form_proses);
        final EditText input_nama = findViewById(R.id.input_nama);
        final EditText input_mulai_main = findViewById(R.id.input_mulai_main);
        final Spinner input_lama_main = findViewById(R.id.input_lama_main);
        final Spinner input_lapangan = findViewById(R.id.input_lapangan);


        ArrayAdapter adapterLapangan = ArrayAdapter.createFromResource(
                this,
                R.array.list_lapangan,
                R.layout.checked_spinner_color
        );
        adapterLapangan.setDropDownViewResource(R.layout.spinner_dropdown_color);
        ArrayAdapter adapterLamaMain = ArrayAdapter.createFromResource(
                this,
                R.array.list_lamamain,
                R.layout.checked_spinner_color
        );
        adapterLamaMain.setDropDownViewResource(R.layout.spinner_dropdown_color);

        input_lapangan.setAdapter(adapterLapangan);
        input_lama_main.setAdapter(adapterLamaMain);


        btnKeFormProses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nama_text = input_nama.getText().toString();
                String mulai_main_text = input_mulai_main.getText().toString();
                String lama_main_text = input_lama_main.getSelectedItem().toString();
                String lapangan_text = input_lapangan.getSelectedItem().toString();
                if(nama_text.isEmpty() || mulai_main_text.isEmpty() || lama_main_text.isEmpty() || lapangan_text.isEmpty()) {
                    Toast.makeText(FormActivity.this, "Isi semua data!", Toast.LENGTH_SHORT).show();
                }else {
                    Intent intent = new Intent(FormActivity.this,FormProsesActivity.class);
                    intent.putExtra("nama", nama_text);
                    intent.putExtra("mulai_main", mulai_main_text);
                    intent.putExtra("lama_main", lama_main_text);
                    intent.putExtra("lapangan", lapangan_text);
                    startActivity(intent);
                }
            }
        });
    }

}