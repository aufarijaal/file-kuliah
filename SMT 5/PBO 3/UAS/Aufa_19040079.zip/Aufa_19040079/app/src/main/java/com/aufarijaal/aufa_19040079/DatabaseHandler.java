package com.aufarijaal.aufa_19040079;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHandler extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "futsal.db";
    private static final int DATABASE_VERSION = 1;
    public final String KEY_ID = "id";
    public final String KEY_TANGGAL_BOOKING = "tanggal_booking";
    public final String KEY_NAMA = "nama";
    public final String KEY_LAPANGAN = "lapangan";
    public final String KEY_HARGA = "harga";
    public final String KEY_LAMA_MAIN = "lama_main";
    public final String KEY_MULAI_MAIN = "mulai_main";
    public final String TABLE_BOOKING = "booking";
    private Cursor cursor;
    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        // TODO Auto-generated constructor stub
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        String sql = "create table if not exists " + TABLE_BOOKING + "(" +
                KEY_ID + " integer primary key autoincrement, " +
                KEY_TANGGAL_BOOKING + " text null, " +
                KEY_NAMA + " text null, " +
                KEY_LAPANGAN + " text null, " +
                KEY_HARGA + " integer null, " +
                KEY_LAMA_MAIN + " text null, " +
                KEY_MULAI_MAIN + " text null);";
        Log.d("Data", "onCreate: " + sql);
        db.execSQL(sql);
    }
    public void tambahBooking(String tanggal_booking, String nama, String lapangan, Integer harga, String lama_main, String mulai_main) {
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = String.format("INSERT INTO booking VALUES(null,\"%s\", \"%s\", \"%s\", %d, \"%s\", \"%s\")", tanggal_booking, nama, lapangan, harga, lama_main, mulai_main);
        db.execSQL(sql);
    }
    Cursor readAllData() {
        String query = "SELECT * FROM " + TABLE_BOOKING;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;
        if(db != null) {
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }
    @Override
    public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {
        // TODO Auto-generated method stub
    }
}
